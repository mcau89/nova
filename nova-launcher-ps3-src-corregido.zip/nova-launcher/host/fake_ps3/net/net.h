#pragma once
#include "../io/pad.h"
s32 netInitialize(void);
