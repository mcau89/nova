#pragma once
#include "../io/pad.h"
typedef struct { u32 numChannels, numBlocks, attr; float level; } audioPortParam;
typedef struct { u64 readIndex; u64 audioDataStart; } audioPortConfig;
#define AUDIO_PORT_2CH 2
#define AUDIO_BLOCK_8 8
s32 audioInit(void); s32 audioPortOpen(audioPortParam*, u32*); s32 audioGetPortConfig(u32, audioPortConfig*);
s32 audioPortStart(u32); s32 audioPortStop(u32); s32 audioPortClose(u32); s32 audioQuit(void);
