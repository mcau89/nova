#pragma once
void sysProcessExit(int);
