#pragma once
#include <stdint.h>
#include <stddef.h>
#include "../io/pad.h"
typedef struct { int dummy; } gcmContextData;
#define GCM_FLIP_VSYNC 1
s32 rsxInit(gcmContextData**, u32, u32, const void*); void gcmSetFlipMode(u32); void* rsxMemalign(u32, u32);
s32 rsxAddressToOffset(void*, u32*); s32 gcmSetDisplayBuffer(u32,u32,u32,u32,u32); void gcmResetFlipStatus(void); u32 gcmGetFlipStatus(void);
s32 gcmSetFlip(gcmContextData*, u32); void rsxFlushBuffer(gcmContextData*); void gcmSetWaitFlip(gcmContextData*);
