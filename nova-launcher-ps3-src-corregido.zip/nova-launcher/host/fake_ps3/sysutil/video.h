#pragma once
#include "../io/pad.h"
typedef struct { u32 x; } videoState; typedef struct { u32 resolution, format, pitch, aspect; } videoConfiguration;
#define VIDEO_RESOLUTION_720 4
#define VIDEO_BUFFER_FORMAT_XRGB 0
#define VIDEO_ASPECT_AUTO 0
s32 videoGetState(u32,u32,videoState*); s32 videoConfigure(u32, videoConfiguration*, void*, u32);
