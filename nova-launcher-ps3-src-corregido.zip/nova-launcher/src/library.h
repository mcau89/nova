#ifndef LIBRARY_H
#define LIBRARY_H

#define MAX_ITEMS 192
#define MAX_FAVS  96

enum { KIND_GAME = 0, KIND_MEDIA = 1, KIND_APP = 2 };

/* Cómo se lanza una tarjeta. Todos son comandos web de webMAN MOD documentados
 * en https://github.com/aldostools/webMAN-MOD/wiki/Web-Commands */
enum {
    ACT_PLAY_PATH = 0,   /* /play.ps3<arg>          arg = ruta de juego, p.ej. /dev_hdd0/GAMES/XXXX */
    ACT_PLAY_QUERY,      /* /play.ps3?<arg>         arg = titleid o nombre (multiman, movian, ...)  */
    ACT_BROWSER_URL,     /* /browser.ps3?<arg>      arg = URL                                       */
    ACT_BROWSER_PATH     /* /browser.ps3<arg>       arg = ruta local, p.ej. /dev_hdd0/video         */
};

typedef struct {
    char id[96];       /* clave estable (favoritos) */
    char name[64];
    char desc[200];
    char tag[40];
    char mono[8];      /* monograma del icono generado */
    char match[96];    /* alternativas en MAYÚSCULAS separadas por '|' para enlazar con el escaneo */
    int kind, hue, act;
    int available;     /* 0 = no instalado (tarjeta atenuada, no se lanza) */
    int favorite;
    int detected;      /* encontrado en el disco */
    char arg[200];
} Item;

typedef struct {
    Item items[MAX_ITEMS];
    int n;
    int section;       /* última sección (persistente) */
    int exit_after;    /* salir del launcher tras pedir el lanzamiento */
    int fx;            /* fondo animado */
    char favs[MAX_FAVS][96];
    int nfavs;
} Library;

void lib_init(Library *l);          /* catálogo estático + valores por defecto */
void lib_scan(Library *l);          /* detecta juegos/apps (solo lectura) */
void lib_load_config(Library *l);
void lib_save_config(const Library *l);
void lib_toggle_fav(Library *l, int idx);
void lib_sync_favs(Library *l);

/* Lee TITLE y TITLE_ID de un PARAM.SFO. Devuelve 1 si pudo leer TITLE. */
int sfo_read(const char *path, char *title, int tn, char *titleid, int idn);

#endif
