#ifndef UI_H
#define UI_H
#include "gfx.h"

typedef struct App App;

/* Crea la app para una superficie de w×h (el diseño escala con h/1080, así
 * 1080p y 720p usan el mismo código). Escanea juegos y carga la configuración. */
App *app_create(int w, int h);
void app_destroy(App *a);

/* Un fotograma: entrada (bits PB_*), avance de animación y dibujado. */
/* Devuelve 1 si redibujó la superficie, 0 si no hizo falta (ahorra CPU). */
int app_frame(App *a, unsigned padraw, float dt);

Surf *app_surface(App *a);
int app_wants_exit(const App *a);

#endif
