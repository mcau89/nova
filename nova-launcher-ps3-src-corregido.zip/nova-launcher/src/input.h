#ifndef INPUT_H
#define INPUT_H

enum {
    PB_UP = 1 << 0, PB_DOWN = 1 << 1, PB_LEFT = 1 << 2, PB_RIGHT = 1 << 3,
    PB_CROSS = 1 << 4, PB_CIRCLE = 1 << 5, PB_TRI = 1 << 6, PB_SQUARE = 1 << 7,
    PB_L1 = 1 << 8, PB_R1 = 1 << 9, PB_START = 1 << 10, PB_SELECT = 1 << 11
};

typedef struct {
    unsigned raw;       /* botones mantenidos este fotograma */
    unsigned prev;
    unsigned pressed;   /* flancos de subida + autorrepetición de la cruceta */
    float hold[4];
    float acc[4];
} Pad;

/* raw ya combina cruceta y joystick izquierdo (lo hace el backend). */
void pad_update(Pad *p, unsigned raw, float dt);

/* Convierte un eje analógico 0..255 (centro ~128) en bits de dirección. */
unsigned pad_stick_dirs(int lh, int lv);

#endif
