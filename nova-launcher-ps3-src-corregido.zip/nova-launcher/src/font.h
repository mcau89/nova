#ifndef FONT_H
#define FONT_H
#include <stdint.h>

/* Glifo pre-rasterizado (alfa 8 bit). bx/by: desplazamiento desde el origen
 * sobre la línea base (by positivo = hacia arriba). */
typedef struct {
    uint16_t cp;
    uint8_t w, h;
    int8_t bx, by;
    uint8_t adv;
    uint32_t off;
} FontGlyph;

typedef struct {
    int px, ascent, lineh, first, count;
} FontSize;

extern const uint8_t font_bitmap[];
extern const FontGlyph font_glyphs[];
extern const FontSize font_sizes[];
extern const int font_nsizes;

#endif
