/* Audio desactivado (make AUDIO=0): el launcher funciona en silencio. */
#include "../src/platform.h"
void plat_sound(int id) { (void)id; }
void audio_init(void) {}
void audio_shutdown(void) {}
void audio_pump(void) {}
