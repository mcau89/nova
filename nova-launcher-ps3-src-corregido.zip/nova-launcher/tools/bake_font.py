#!/usr/bin/env python3
"""Pre-rasteriza la fuente Inter (SIL OFL 1.1) en bitmaps alfa de 8 bits y los
emite como src/font_data.c. Así el launcher no necesita FreeType ni ficheros
de fuente en la PS3: el texto sale anti-aliased y con tipografía moderna.

Uso: python3 tools/bake_font.py [ruta/Inter-SemiBold.otf]
"""
import os
import sys
from PIL import Image, ImageDraw, ImageFont

FONT = sys.argv[1] if len(sys.argv) > 1 else "/usr/share/fonts/opentype/inter/Inter-SemiBold.otf"
SIZES = [20, 30, 44, 64, 88]
CHARS = sorted(set([chr(c) for c in range(32, 127)] + list("áéíóúñÁÉÍÓÚÑüÜ¿¡·…")))
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "font_data.c")

bitmap = bytearray()
glyph_rows = []
size_rows = []

for px in SIZES:
    font = ImageFont.truetype(FONT, px)
    ascent, descent = font.getmetrics()
    first = len(glyph_rows)
    for ch in CHARS:
        adv = int(round(font.getlength(ch)))
        l, t, r, b = font.getbbox(ch, anchor="ls")
        w, h = max(0, r - l), max(0, b - t)
        off = len(bitmap)
        if ch != " " and w > 0 and h > 0:
            img = Image.new("L", (w, h), 0)
            ImageDraw.Draw(img).text((-l, -t), ch, font=font, fill=255, anchor="ls")
            bitmap.extend(img.tobytes())
        else:
            w = h = 0
        glyph_rows.append((ord(ch), w, h, l, -t, adv, off))
    size_rows.append((px, ascent, ascent + descent, first, len(CHARS)))

with open(OUT, "w", encoding="utf-8") as f:
    f.write("/* GENERADO por tools/bake_font.py a partir de Inter SemiBold (SIL OFL 1.1). No editar. */\n")
    f.write('#include "font.h"\n\n')
    f.write("const uint8_t font_bitmap[%d] = {\n" % len(bitmap))
    for i in range(0, len(bitmap), 40):
        f.write(",".join(str(v) for v in bitmap[i:i + 40]) + ",\n")
    f.write("};\n\n")
    f.write("const FontGlyph font_glyphs[%d] = {\n" % len(glyph_rows))
    for g in glyph_rows:
        f.write("{%d,%d,%d,%d,%d,%d,%d},\n" % g)
    f.write("};\n\n")
    f.write("const FontSize font_sizes[%d] = {\n" % len(size_rows))
    for s in size_rows:
        f.write("{%d,%d,%d,%d,%d},\n" % s)
    f.write("};\nconst int font_nsizes = %d;\n" % len(size_rows))

print("OK: %d glifos, %d bytes de bitmap -> %s" % (len(glyph_rows), len(bitmap), os.path.normpath(OUT)))
