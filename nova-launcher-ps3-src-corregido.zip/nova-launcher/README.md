# Nova Launcher — launcher horizontal para PS3 con HEN

Launcher **nativo** (homebrew en C con PSL1GHT) con la composición del menú principal
de PS5: pestañas arriba a la izquierda, lupa/engranaje/avatar/reloj arriba a la derecha,
fila de cuadraditos con el seleccionado más grande y su nombre al lado, fondo a pantalla
completa con el arte del elemento, título + botón abajo a la izquierda, carátula chica a
la derecha y tres paneles inferiores. Animaciones y sonidos propios.
Todos los gráficos, la tipografía (Inter, licencia OFL) y los sonidos son
**originales**; no se usa ningún recurso de Sony.

## Estado real (léelo antes de instalar)

| Pieza | Estado |
|---|---|
| Interfaz, navegación, tarjetas, favoritos, persistencia, detección de juegos, construcción de peticiones a webMAN | **Hecho y probado en PC** (18 pruebas automáticas + capturas 1080p/720p) |
| Backend de PS3 (vídeo RSX, mando, sysutil, sockets) | **Escrito, NO compilado** — no había toolchain de PS3 ni red en el entorno de desarrollo |
| Audio en PS3 | **Escrito, NO compilado** (`make AUDIO=0` lo desactiva) |
| **PKG instalable** | **NO generado.** Requiere la toolchain de PS3, que no se pudo instalar aquí. Ver `docs/BUILD.md` |
| Rendimiento en la consola | **Sin medir.** El render es por software; en PC cuesta ~7 ms/fotograma a 720p, la PPU es bastante más lenta |

No te prometo que el primer `make pkg` salga limpio: las llamadas de vídeo/audio/red
de PSL1GHT están escritas según el patrón de sus ejemplos, y los puntos dudosos
están marcados con `VERIFICAR` en el código. `docs/BUILD.md` lista cada uno.

## Estructura

```
src/            núcleo común (UI, gráficos, biblioteca, lanzamiento, HTTP, fuente embebida)
ps3/            backend de PS3: main_ps3.c (vídeo/mando/sistema), audio_ps3.c / audio_stub.c
host/           backend de PC para pruebas + run_tests.sh (18 pruebas)
tools/          bake_font.py (rasteriza Inter), gen_assets.py (sonidos + ICON0)
assets/         ICON0.PNG y los 5 sonidos .wav originales
docs/BUILD.md   cómo obtener el PKG, verificación pendiente, limitaciones
Makefile        PKG de PS3 (PSL1GHT)
```

## Controles

Cruceta o joystick izquierdo: moverse · **X** lanzar · **O** volver al primer elemento / a Juegos ·
**△** añadir/quitar favorito · **L1/R1** cambiar de sección · en Biblioteca, ↑ para elegir
Juegos instalados / Aplicaciones instaladas / Favoritos.

## Cómo lanza juegos y apps (sin inventar APIs)

PSL1GHT no tiene una API documentada para arrancar otro juego. El launcher usa la
**API web de webMAN MOD**, que corre en la propia consola, con comandos que figuran
en su wiki oficial (`Web-Commands`):

| Tarjeta | Petición a `http://127.0.0.1/…` |
|---|---|
| Juego en `/dev_hdd0/GAMES` / `GAMEZ` / `PS3ISO` | `/play.ps3/<ruta>` |
| Deep Play / apps o PSN en `/dev_hdd0/game` | `/play.ps3?<ID de contenido>` |
| multiMAN | `/play.ps3?multiman` |
| webMAN MOD / Ajustes / Navegador | `/browser.ps3?<url>` (`/setup.ps3` para ajustes) |
| Música / Vídeos / Imágenes | `/browser.ps3/<carpeta>` |

Si webMAN no responde, el launcher muestra el error y **no se cierra**. Un HTML no
puede lanzar juegos de PS3; aquí lo hace la app nativa pidiéndoselo a webMAN.

## Lo que NO hace (y la alternativa)

- **Multimedia no reproduce dentro del launcher.** No encontré en la documentación de
  webMAN un comando para abrir los reproductores del XMB. Alternativa: abre el
  explorador de archivos de webMAN sobre `/dev_hdd0/music|video|photo`.
- **Solo detecta** `/dev_hdd0/GAMES`, `GAMEZ`, `PS3ISO` y `/dev_hdd0/game`. No escanea USB/NTFS/red todavía.
- **Imágenes de tarjeta y fondos:** son arte generado (inicial + color por título), no portadas reales.
- **Lupa, engranaje y avatar son decorativos** (no abren nada). El reloj usa la hora del sistema; puede mostrar UTC si la consola no tiene zona horaria.
- **Los paneles inferiores** muestran datos reales (ID, nº de favoritos, controles), no trofeos ni amigos.
- Al cambiar de elemento por primera vez se genera su fondo (un pequeño tirón en PS3; luego queda en caché).
- **Puerto de webMAN:** asumo 80 (`WM_PORT`); la wiki no lo especifica.
- **Qué pasa con el launcher al arrancar un juego:** por defecto sale tras pedírselo a webMAN
  (`exit_after=1`). No pude comprobar en consola si hace falta otra secuencia.

## Seguridad de tus datos

Solo lectura sobre `GAMES`, `GAMEZ`, `PS3ISO` y los `PARAM.SFO`/existencia de `EBOOT.BIN`
en `game/`. Nunca se abre `savedata`. Lo único que se escribe es `config.txt` en la
carpeta propia (`/dev_hdd0/game/PS5LNCH00/USRDIR/`). No toca HEN, multiMAN ni webMAN.
(La prueba automática comprueba que una carpeta de savedata de ejemplo queda intacta.)

## Probar la interfaz en PC (sin PS3)

```
cd host && ./run_tests.sh                      # 18 pruebas
make -C host host PS3_ROOT=/ruta/falsa WM_PORT=18080
SCRIPT="R1,R1*,RIGHT*" ./host/host 1920 1080 salida   # capturas PPM por guion
```
